from my_module import Class1

import os

from my_module import Class3

from my_module import Class2

import sys


print(os.getcwd())