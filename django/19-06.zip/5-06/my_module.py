class Class1:
    pass


class Class2:
    pass


class Class3:
    pass